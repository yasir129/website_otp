<?php
	include_once 'header1.php';
  	include_once $pageName.'.php';
?>