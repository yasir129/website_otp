<?php
	class Handler_db extends CI_model{
		public function validation_phone_number($phone_number,$password){
			// $user_details= $this->db->query("SELECT * FROM users")->result_array();
			// $user_details=$this->db->get('users')->result_array();

			$this->db->where('phone_number',$phone_number);
			$this->db->where('password',$password);
			$query = $this->db->get('users');
			if($query->num_rows() > 0 ){
				return true;
			}
			else{
				return false;
			}
			
		}
		public function insert_user_details($phone_number,$password){
			$data = array(
			   'phone_number' => $phone_number ,
			   'password' => $password 
			);
			$this->db->insert('users',$data);

		}
		public function val_pho($phone_number){

			$this->db->where('phone_number',$phone_number);
			$query = $this->db->get('users');
			if($query->num_rows() > 0 ){
				return false;
			}
			else{
				return true;
			}
		}
		public function update_otp($phone_number,$password){
			$data = array(
               'password' => $password
            );
			$this->db->where('phone_number', $phone_number);
			$this->db->update('users', $data);
		}
		public function id_getter($phone_number,$password){
			$this->db->select('Id');
			$this->db->where('phone_number',$phone_number);
			$this->db->where('password',$password);
			$query = $this->db->get('users')->result_array();
			return $query;
		}
		public function fetch_data($Id){
			
			$this->db->select('medication.Id,medication_name,dosage');
			$this->db->from('users');
			$this->db->join('medication','medication.user_id = users.Id','inner');
			$this->db->where('users.Id',$Id);
			$query = $this->db->get()->result_array();
			return $query;


		}
		public function remove_data($id){
			$this->db->where('medication_id', $id);
			$this->db->delete('week');
			$this->db->where('medication_id', $id);
			$this->db->delete('times');
			$this->db->where('Id', $id);
			$this->db->delete('medication');
		}
		public function add_medic($med_name,$dosage,$id,$o_day,$o_month,$meal,$time,$weekly){
			if($weekly == "NOP"){
				$data = array(
					'medication_name'=>$med_name,
					'dosage'=>$dosage,
					'user_id'=>$id,
					'once_day'=>$o_day,
					'once_month'=>$o_month,
					'meal'=>$meal
				);
				$this->db->insert('medication',$data);
				$this->db->select_max('Id');
				$ID = $this->db->get('medication')->result_array();
				foreach($time as $v){
					$data1 = array(
						'medication_id'=>$ID[0]['Id'],
						'time'=> $v
					);
					$this->db->insert('times',$data1);
				}
			}
			else{
				$data = array(
					'medication_name'=>$med_name,
					'dosage'=>$dosage,
					'user_id'=>$id,
					'once_day'=>$o_day,
					'once_month'=>$o_month,
					'meal'=>$meal
				);
				$this->db->insert('medication',$data);
				$this->db->select_max('Id');
				$ID = $this->db->get('medication')->result_array();
				foreach($time as $v){
					$data1 = array(
						'medication_id'=>$ID[0]['Id'],
						'time'=> $v
					);
					$this->db->insert('times',$data1);
				}
				foreach($weekly as $v){
					$data1 = array(
						'medication_id'=>$ID[0]['Id'],
						'week'=> $v
					);
					$this->db->insert('week',$data1);
				}
			}
		}
	}
?>